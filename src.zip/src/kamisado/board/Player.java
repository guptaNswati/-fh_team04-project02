package kamisado.board;

public enum Player { WHITE, BLACK };
