package kamisado.board;

/**
 * 
 * @author chris
 * Board Colors for Kamisado
 */

public enum Color { GREEN, BLUE, PINK, RED, BROWN, ORANGE, YELLOW, PURPLE };



